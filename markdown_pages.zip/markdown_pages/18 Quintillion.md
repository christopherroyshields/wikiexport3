# 18 Quintillion

## 18 Quintillion[edit]

This is roughly 2\*\*64 or 18,446,744,073,709,551,616.

This is the theoretical maximum file size for a Business Rules data file.

- - Note: There is a more practical 2\*\*31 or 2,147,483,648 actual record limit.

If you had 2\*31 2048 byte records, the file size would be 4 trillion or (4,398,046,511,104) bytes.