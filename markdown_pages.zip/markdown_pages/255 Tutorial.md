# 255 Tutorial

Historically, to print to a printer, BR used the file number 255, which was reserved for this purpose. With Native Windows Printing now compatible with BR, this is no longer necessary. In this tutorial, we will attempt to explain both, so that you will be comfortable with both older and newer printing jobs.

Printing with #255, means it must also first be OPENed, PRINTed to, and then CLOSEd, as in this short example:

00010 OPEN #255: "name=PREVIEW:/DEFAULT,recl=32000", DISPLAY,OUTPUT
00020 PRINT #255: "My first printout!"
00030 CLOSE #255:

We use a print preview to save paper for the examples in this tutorial. To print to an actual printer, change PREVIEW to PRN.

Originally, BR used non-proportional fonts, so to print correctly on the page, it was important to pay attention to the lines and spaces so that everything lines up correctly. If you are updating legacy reports, it's simplest to choose a modern-looking non-proportional to work within the constrains of legacy alignment. For creating a new report, however, you probably wish to use a modern proportional font since you'll be aligning everything for the first time.

BR programs often use the FORM statement to format the printout. For example:

```
print #255,using nameform: A$(1),A$(2),A$(3)
nameform: form Pos 14,C 30,Skip 1,Pos 14,C 30,Skip 1,Pos 14,C 30,Skip 8

```
```
print #255:

```

will simple print a blank line. Skip 1 will do the same. All lines will perform a carriage return and start the next line one down, unless it's followed by a semi-colon (;).

```
   print #255, using curform:B(2),B(4),B(5),B(12),sum(mat B(13:21))
   curform: form pos 102,pic(z,zz#.##), skip 1

```

The syntax then, for PRINT USING, is as follows:

```
PRINT #255, USING line-ref or string expression : data item or MAT array-name

```

In the example above, curform is the line ref and the data items are listed after the colon. Within the line curform, notice that most normal format specifications apply to print statements too.

Using a file Printer.sys, you can set fonts and styles using subattributes too.

If the program does not use #255, then the printout goes to prn:/10, which would be the currently designated printer.

Next: Push and Pop

Back: Table of Contents