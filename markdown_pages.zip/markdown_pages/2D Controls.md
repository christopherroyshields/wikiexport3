# 2D Controls

A **2D Control** is a widget involving vertical math such as a list, grid, or a combobox. Not all input enabled elements of a graphic user interface are considered as 2D controls. Radio Buttons and checkboxes, for example, are only 1D controls, because Business Rules! doesn't need to do any additional line based vertical math to interface with the widget.

PRINT FIELDS "nn,nn,GRID 10/40,ATTR": (mat start, mat end, mat attr$)
Overrides the attributes of a range of cells/rows for a GRID/LIST display. This allows you to shade or otherwise alter the display of a range of cells / rows in a 2D Control. The P (protect) attribute is also supported on GRID PRINT ATTR statements. To clear such attribute overrides simply PRINT ATTR to the same cells using a null (empty string) attribute specification.

AEX and P are now supported in HEADERS column attributes.